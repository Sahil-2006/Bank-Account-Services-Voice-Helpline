"""Normalize common English ASR forms at the point a date or amount is expected."""
import re
UNITS = dict(zip('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split(), range(20)))
TENS = dict(zip('twenty thirty forty fifty sixty seventy eighty ninety'.split(), range(20, 100, 10)))
ORDINALS = 'first second third fourth fifth sixth seventh eighth ninth tenth eleventh twelfth thirteenth fourteenth fifteenth sixteenth seventeenth eighteenth nineteenth twentieth'.split()
MONTHS = 'january february march april may june july august september october november december'.split()

def spoken_int(text):
    words = text.lower().replace('-', ' ').replace(',', '').split()
    total = part = 0
    for word in words:
        if word == 'and':
            continue
        if word in UNITS or word in TENS or word.isdigit():
            part += int(word) if word.isdigit() else UNITS.get(word) if word in UNITS else TENS[word]
        elif word == 'hundred' and part:
            part *= 100
        elif word in ('thousand', 'lakh') and part:
            total += part * (1000 if word == 'thousand' else 100000)
            part = 0
        else:
            return None
    return total + part if words else None

def date_words(text):
    t = re.sub('(\\d+)(st|nd|rd|th)\\b', '\\1', text.lower())
    t = t.replace(',', ' ').replace('-', ' ').replace('the ', '').replace(' of ', ' ')
    for n, word in enumerate(ORDINALS, 1):
        t = re.sub('\\b' + word + '\\b', str(n), t)
    t = t.replace('thirtieth', '30')
    parts = t.split()
    for i, month in enumerate(MONTHS, 1):
        if month not in parts:
            continue
        m = parts.index(month)
        if m:
            day = spoken_int(' '.join(parts[:m]))
            year = parts[m + 1:]
        else:
            if len(parts) < 3:
                return ''
            count = 2 if parts[1] in ('twenty', 'thirty') and len(parts) > 3 and parts[2].isdigit() and (int(parts[2]) < 10) else 1
            day = spoken_int(' '.join(parts[1:1 + count]))
            year = parts[1 + count:]
        if len(year) > 1 and year[0] in ('nineteen', 'twenty') and ('hundred' not in year):
            tail = spoken_int(' '.join(year[1:]))
            y = None if tail is None else UNITS.get(year[0], 20) * 100 + tail
        else:
            y = spoken_int(' '.join(year))
        if day and y and (1000 <= y <= 9999):
            return f'{y:04d}-{i:02d}-{day:02d}'
    return ''

"""Deterministic rules shared by the local desk and the Studio tool builder."""
import re
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, ROUND_CEILING
NOW = '2026-11-10T09:00:00+05:30'
CRISIS = "I'm really sorry you're going through this. You are not alone, and help is available. If you are in immediate danger, please call 112 now. You can also call Tele-MANAS on 14416, free and open at all hours, to talk to a trained counsellor. I'm connecting you with a person now."
PRIVATE = 'Please keep card, Aadhaar and PIN numbers private. I only need the requested verification details.'
SAFE = 'I can only share verified account information from our tools. Would you like a person?'
TERMS = "Limits and fees follow the bank's terms."
HUMAN = "I'm connecting you with a person now."
TECH = "I couldn't retrieve the account information."
ADVICE = "I can't give financial advice. Would you like a person?"
OUTSIDE = 'I can help with bank account services. Would you like a person?'
DIGITS = 'zero one two three four five six seven eight nine'.split()
DIGIT_MAP = {**{word: str(i) for i, word in enumerate(DIGITS)}, 'oh': '0'}
NOW_DAY = NOW[:10]
CALENDAR_CACHE = {'england-and-wales': {'events': [{'date': '2026-01-01'}, {'date': '2026-04-03'}, {'date': '2026-04-06'}, {'date': '2026-05-04'}, {'date': '2026-05-25'}, {'date': '2026-08-31'}, {'date': '2026-12-25'}, {'date': '2026-12-28'}, {'date': '2027-01-01'}, {'date': '2027-03-26'}, {'date': '2027-03-29'}, {'date': '2027-05-03'}, {'date': '2027-05-31'}, {'date': '2027-08-30'}, {'date': '2027-12-27'}, {'date': '2027-12-28'}]}}

def clean(text):
    return ' '.join(text.lower().replace('’', "'").strip().split())

def number_tokens(text):
    return re.sub('\\b(' + '|'.join(DIGIT_MAP) + ')\\b', lambda m: DIGIT_MAP[m.group()], clean(text))

def compact_digits(text):
    return re.sub('[\\s,.-]', '', number_tokens(text))

def classify(text):
    t = clean(text)
    if re.search("\\b(?:suicidal|suicide|kill myself|end my life|hurt myself|harm myself|tak(?:e|ing) my own life|don't want to (?:live|be alive)|do not want to live|can't keep myself safe)\\b", t):
        return 'crisis'
    if re.search('\\bhow (?:can|do) i (?:hurt|harm|attack) (?:someone|a person|people)\\b', t):
        return 'harm'
    if re.fullmatch('(?:please\\s+)?(?:0|zero)[.!?]?', t) or re.search('\\b(?:agent|representative|someone|human|real person|a person)\\b', t):
        return 'human'
    numbers = number_tokens(t)
    if re.search('(?<!\\d)(?:\\d[\\s,-]*){12,}(?!\\d)', numbers) or (re.search('\\b(?:pin|card|aadhaar|aadhar|pan)\\b', t) and re.search('\\d', numbers)) or re.fullmatch('[A-Z]{5}\\d{4}[A-Z]', t.upper()):
        return 'private'
    if re.search('\\b(?:ignore|override|disregard)\\b.*\\b(?:instructions|rules|system)\\b|\\breveal (?:the |your )?system prompt\\b', t):
        return 'prompt'
    if re.search('\\b(?:invest|investment advice|buy stocks|sell shares|which stock|best mutual fund|should i borrow)\\b', t):
        return 'advice'
    if re.search('\\b(?:weather|recipe|pizza|football|flight|movie|train ticket)\\b', t):
        return 'outside'
    return ''

def intent_of(text):
    t = clean(text).strip('.!?')
    keypad = {'one': 'balance', '1': 'balance', 'two': 'statement', '2': 'statement', 'three': 'limit', '3': 'limit'}
    found = [i for i, pattern in (('balance', '\\bbalance\\b'), ('statement', '\\bstatements?\\b'), ('limit', '\\blimits?\\b'), ('deposit', '\\bdeposit\\b'), ('withdraw', '\\bwithdraw(?:al)?\\b')) if re.search(pattern, t)]
    transactions = [item for item in found if item in ('deposit', 'withdraw')]
    if len(transactions) == 1:
        return transactions[0]
    return keypad.get(t, found[0] if len(found) == 1 else '')

def resolve_channel(name, transfer_date):
    try:
        day = date.fromisoformat(transfer_date)
    except (ValueError, TypeError):
        return ''
    cutover = date(2027, 1, 1)
    key = re.sub('[\\s-]+', '', clean(name))
    if key == 'instantpay':
        return 'Instant Pay'
    if key in ('bankwire', 'bankwireplus'):
        return 'BankWire Plus' if day >= cutover else 'BankWire'
    if key == 'passbookexpress' and day < cutover:
        return 'PassBook Express'
    if key == 'kitepay':
        return 'KitePay'
    return ''

def positive(value):
    try:
        n = Decimal(str(value).replace(',', '').strip())
        if n.is_finite() and n > 0:
            return n
    except (InvalidOperation, TypeError, ValueError):
        pass
    return None

def charge(months, delivery):
    n = positive(months)
    if n is None or delivery not in ('digital', 'printed'):
        return {'error': 'invalid'}
    if n > 36:
        return {'error': 'archive'}
    rounded = int(n.to_integral_value(rounding=ROUND_CEILING))
    fees = ((0, 100), (100, 250), (300, 500))
    tier = 0 if rounded <= 3 else 1 if rounded <= 12 else 2
    return {'months': rounded, 'fee': fees[tier][delivery == 'printed']}

def as_digits(value):
    return ' '.join((DIGITS[int(c)] for c in value if c.isdigit()))

def safe_output(text, allowed_money=()):
    if text == CRISIS:
        return text
    if re.search('(?:\\d[\\s,-]*){12,}', number_tokens(text)) or re.search('\\b(?:you should (?:buy|invest|sell)|i recommend investing)\\b', clean(text)):
        return SAFE
    numbers = number_tokens(text)
    if re.search('\\b(?:account (?:number|ending)|account ends in)\\D{0,12}(?:\\d[\\s-]*){5,}', numbers):
        return SAFE
    amounts = re.findall('\\b([\\d,]+(?:\\.\\d+)?)\\s+rupees\\b', text.lower())
    amounts += re.findall('(?:₹|\\b(?:rs\\.?|inr|rupees)\\s+)\\s*([\\d,]+(?:\\.\\d+)?)', text.lower())
    if any((Decimal(v.replace(',', '')) not in allowed_money for v in amounts)):
        return SAFE
    return text

def _calendar_date(day, data):
    try:
        target = date.fromisoformat(day)
        events = data['england-and-wales']['events']
        listed = {date.fromisoformat(event['date']) for event in events}
        if target.year not in {d.year for d in listed}:
            return None
        candidate = target
        for _ in range(15):
            if candidate.weekday() < 5 and candidate not in listed:
                return candidate
            candidate += timedelta(days=1)
        return None
    except (KeyError, ValueError, TypeError):
        return None

def uk_clearing_date(day, data, fallback=None):
    """Return the next England and Wales business date from the live feed or cache."""
    cached = CALENDAR_CACHE if fallback is None else fallback
    source = data.get('_source', '') if isinstance(data, dict) else ''
    if source != 'cache':
        result = _calendar_date(day, data)
        if result:
            return {'available': True, 'date': result.isoformat(), 'adjusted': result.isoformat() != day, 'source': 'live'}
    result = _calendar_date(day, cached)
    if result:
        return {'available': True, 'date': result.isoformat(), 'adjusted': result.isoformat() != day, 'source': 'cache'}
    return {'available': False, 'date': '', 'adjusted': False, 'source': 'unavailable'}

def uk_advisory(day, data, fallback=None):
    result = uk_clearing_date(day, data, fallback)
    if not result['available']:
        return "I couldn't check the UK clearing calendar."
    clearing = date.fromisoformat(result['date'])
    label = f"{clearing.day} {clearing.strftime('%B %Y')}"
    prefix = 'The live GOV.UK feed was unavailable; I used the cached calendar. ' if result['source'] == 'cache' else ''
    if result['adjusted']:
        return prefix + f'The UK clearing date moves to {label} after a weekend or bank holiday.'
    return prefix + f'The UK clearing date is {label}.'

"""Rules take a server-owned session and the fictional directory as inputs."""
import re

def fresh():
    return dict(verified=False, customer_id='', account_type='', intent_tag='', channel='', attempts=0, unclear=0, now_override=NOW, handoff={}, pending={}, quote={}, stage='id', candidate='', ending='', dob='', retry_stage='', period='', delivery='', offered=False, demo_record_ready=False, demo_customer_id='', demo_balance=0, demo_tx_amount='', demo_return_stage='demo_service', demo_balance_active=False)

def finish(s, destination, reason, channel=''):
    if not s['handoff']:
        s['handoff'] = {'destination': destination, 'reason': reason, 'intent': s['intent_tag'], 'channel': channel}
        s['stage'] = 'closed'
        s['pending'] = {}
        s['dob'] = ''
        s['candidate'] = ''
    return s['handoff']

def verify_caller(s, directory, customer_id, dob, last_four):
    if s['handoff']:
        return {'result': 'closed'}
    if s['verified']:
        return {'result': 'verified'}
    key = compact_digits(customer_id).upper()
    try:
        rows = [r for r in directory if r['id'] == key]
    except (OSError, TypeError, KeyError):
        finish(s, 'human', 'lookup')
        return {'result': 'technical'}
    if len(rows) != 1:
        finish(s, 'human', 'lookup')
        return {'result': 'technical'}
    row = rows[0]
    failed_fields = []
    if row.get('dob') != dob:
        failed_fields.append('dob')
    if row.get('last4') != compact_digits(last_four):
        failed_fields.append('ending')
    if not failed_fields and row.get('customer_status') == 'BLOCKED':
        finish(s, 'human', 'restricted')
        return {'result': 'human'}
    if not failed_fields and row.get('customer_status') != 'ACTIVE':
        finish(s, 'human', 'lookup')
        return {'result': 'technical'}
    s['attempts'] += 1
    if not failed_fields:
        s.update(verified=True, customer_id=key, ending=row['last4'], stage='service', attempts=0, retry_stage='')
        return {'result': 'verified'}
    if s['attempts'] >= 3:
        finish(s, 'human', 'verification')
        return {'result': 'human'}
    return {'result': 'retry', 'failed_fields': failed_fields}

def lookup_account(s, directory):
    if not s['verified'] or s['handoff']:
        return {}
    try:
        row = next((r for r in directory if r['id'] == s['customer_id']), None)
    except (OSError, TypeError, KeyError):
        row = None
    if not row or not row.get('account'):
        finish(s, 'human', 'lookup')
        return {}
    s['account_type'] = row['plan'] or ''
    return row

def check_status(s, row):
    if not row:
        return False
    if row.get('status') != 'ACTIVE':
        reason = 'status' if row.get('status') in ('FROZEN', 'DORMANT') else 'unknown_status'
        finish(s, 'human', reason)
        return False
    return True

def quote_balance(s, rows):
    row = lookup_account(s, rows)
    if s['intent_tag'] != 'balance' or not check_status(s, row):
        return {}
    if row['balance'] is None:
        finish(s, 'human', 'lookup')
        return {}
    return prepare(s, row, {'balance': row['balance']}, row['channel'], s['now_override'][:10])

def quote_statement(s, rows, months, delivery, sent_today=False):
    row = lookup_account(s, rows)
    if not row or s['intent_tag'] != 'statement':
        return {}
    if not check_status(s, row):
        return {}
    if sent_today or row['last_sent'] == s['now_override'][:10]:
        finish(s, 'human', 'already_sent')
        return {}
    q = charge(months, delivery)
    if q.get('error') == 'archive':
        finish(s, 'human', 'archive')
        return {}
    if 'error' in q:
        return q
    q['delivery'] = delivery
    return prepare(s, row, q, row['channel'], s['now_override'][:10])

def check_limit(s, rows, amount, channel, transfer_date):
    row = lookup_account(s, rows)
    if s['intent_tag'] != 'limit' or not check_status(s, row):
        return {}
    cap = {'Basic': 25000, 'Premium': 100000}.get(row['plan'])
    if cap is None:
        finish(s, 'human', 'unknown_plan')
        return {}
    value = positive(amount) if amount != '' else None
    key = re.sub('[\\s-]+', '', clean(channel))
    if key == 'kitepay' and (value is None or value > 1):
        finish(s, 'human', 'unsupported_channel')
        return {}
    if not resolve_channel(channel, transfer_date):
        finish(s, 'human', 'unsupported_channel')
        return {}
    if amount != '' and positive(amount) is None:
        return {'error': 'invalid'}
    if amount != '' and positive(amount) > cap:
        finish(s, 'human', 'above_limit')
        return {}
    return prepare(s, row, {'limit': cap}, channel, transfer_date)

def prepare(s, row, quote, channel, day):
    route = resolve_channel(channel or '', day)
    if not route:
        finish(s, 'human', 'unsupported_channel')
        return {}
    s.update(channel=route, quote=quote, pending={'channel': route, 'date': day})
    return quote

def complete_handoff(s):
    if s['verified'] and s['pending'] and s['quote'] and (not s['handoff']):
        return finish(s, 'channel', 'service_complete', s['pending']['channel'])
    return s['handoff']

def human_message(s):
    from_reason = {'lookup': TECH, 'unknown_status': TECH, 'unknown_plan': TECH, 'already_sent': 'A statement was already sent today.', 'archive': 'This period needs help from a colleague.', 'above_limit': 'That amount exceeds the daily limit.', 'calendar': "I couldn't check the UK clearing calendar.", 'unsupported_channel': 'That channel is unavailable for this transfer. Available channels are Instant Pay, BankWire (BankWire Plus from 1 January 2027), PassBook Express through 31 December 2026, and KitePay for 1-rupee micro-payments.', 'status': 'This account needs help from a colleague.'}
    return from_reason.get(s['handoff'].get('reason'), '')

"""Conversation controller. Only synthetic directory records reach this module."""
import re
from datetime import date, datetime
from decimal import Decimal
WELCOME = 'Welcome to Harbour Trust. What is your customer ID?'
MENU = 'Would you like your balance, a statement, or a transfer limit?'
ASK = {'id': 'What is your customer ID?', 'dob': 'What is your date of birth?', 'ending': 'What are the last four account digits?', 'service': MENU, 'months': 'How many months should the statement cover?', 'delivery': 'Would you like a digital or printed copy?', 'amount': 'What transfer amount should I check, or should I just read the limit?', 'channel': 'Which transfer channel will you use?', 'date': 'On what date will you make the transfer?', 'open_name': 'For this demo only, what fictional full name should I use?', 'open_phone': 'For this demo only, enter the sample phone number 0000000000.', 'open_dob': 'For this demo only, what fictional date of birth should I use?', 'open_aadhaar': 'Aadhaar verification is simulated. Say ‘demo verified’; do not share an Aadhaar number.', 'open_pan': 'For this simulation only, enter the sample token DEMO-PAN. Never enter a real PAN.', 'open_confirm': 'I have the demo details. No personal details will be saved. Say yes to create a demo profile, or no to cancel.', 'demo_service': 'You can check your demo balance, make a simulated deposit or withdrawal, or say finish.', 'demo_tx_amount': 'What amount should I use for the simulated transaction? Enter a positive amount.', 'demo_tx_confirm': 'Confirm this simulated transaction? Say yes to apply it to the demo balance, or no to cancel.'}
YES = {'yes', 'yeah', 'correct', "that's right", 'right', 'yes please', 'that is correct'}
NO = {'no', 'incorrect', 'wrong', 'no thanks', 'no thank you'}
PAN_PRIVATE = 'Please keep PAN numbers private. This demo simulates identity checks and does not need a PAN number.'
DEMO_PAN = 'DEMO-PAN'

def parse_day(text):
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d %B %Y', '%B %d %Y', '%d %b %Y'):
        try:
            return datetime.strptime(text.replace(',', '').strip(), fmt).date().isoformat()
        except ValueError:
            pass
    normalized = date_words(text)
    if normalized:
        try:
            return date.fromisoformat(normalized).isoformat()
        except ValueError:
            pass
    return ''

def period_value(text):
    t = clean(text).replace(' and a half', '.5')
    for w, n in {'twelve': '12', 'thirty six': '36', 'three': '3', 'six': '6', 'one': '1'}.items():
        t = re.sub('\\b' + w + '\\b', n, t)
    m = re.fullmatch('([+-]?\\d+(?:\\.\\d+)?)\\s*(?:months?)?[.!]?', t.replace(' .', '.'))
    return m.group(1) if m and positive(m.group(1)) else ''

def current_prompt(s):
    if s['stage'] == 'confirm_id':
        return 'I heard H T ' + as_digits(s['candidate'][2:]) + ', ending ' + as_digits(s['ending']) + '. Is that right?'
    if s['stage'] == 'confirm_period':
        return 'You asked for ' + s['period'] + ' months. Is that right?'
    return ASK.get(s['stage'], MENU)

def is_account_opening_request(text):
    has_action = re.search('\\b(?:open|create|start|new|apply|register|sign\\s+up)\\b', text)
    has_account = re.search('\\b(?:bank\\s+)?account\\b|\\baccount opening\\b', text)
    return bool(has_action and has_account)

class Desk:

    def __init__(self, directory, state=None, calendar=None, reserve=None, callback=None):
        self.rows = directory
        self.s = state if state is not None else fresh()
        self.calendar = calendar
        self.reserve = reserve
        self.callback = callback
        self.trace = []

    def run_tool(self, func, *args):
        self.trace.append(func.__name__)
        return func(self.s, *args)

    def turn(self, raw):
        s = self.s
        if s['handoff']:
            return 'This call has ended.'
        s['demo_record_ready'] = False
        text = clean(raw).strip('!?')
        kind = classify(text)
        if kind == 'private' and s['stage'] == 'open_pan' and (text.upper() == DEMO_PAN):
            kind = ''
        if kind in ('crisis', 'human'):
            if not s['intent_tag']:
                s['intent_tag'] = intent_of(text)
            self.run_tool(finish, 'human', kind)
            reply = CRISIS if kind == 'crisis' else HUMAN
        elif kind == 'private':
            reply = PAN_PRIVATE if re.search('\\bpan\\b', text) or re.fullmatch('[A-Z]{5}\\d{4}[A-Z]', text.upper()) else PRIVATE
        elif kind in ('prompt', 'harm'):
            reply = SAFE
            s['offered'] = True
        elif kind in ('advice', 'outside'):
            s['offered'] = True
            reply = ADVICE if kind == 'advice' else OUTSIDE
        elif s['offered'] and text in YES:
            self.run_tool(finish, 'human', 'accepted_offer')
            reply = HUMAN
        elif not text:
            reply = 'Take your time. ' + current_prompt(s)
        elif re.search('\\b(?:what can you do|what services|what do you do)\\b', text):
            reply = 'I can check a balance, arrange a statement, or look up a transfer limit. ' + current_prompt(s)
        else:
            if s['offered'] and text in NO:
                reply = current_prompt(s)
            else:
                reply = self.process(text)
            s['offered'] = False
        if s['handoff'] and self.callback:
            self.callback(dict(s['handoff']))
        allowed = [Decimal(str(v)) for k, v in s['quote'].items() if k in ('balance', 'fee', 'limit')]
        allowed.extend((Decimal(str(value)) for value in (s.get('demo_balance'), s.get('demo_tx_amount')) if value not in (None, '')))
        return safe_output(reply, allowed)

    def process(self, text):
        s = self.s
        stage = s['stage']
        if stage in ('id', 'dob', 'ending', 'confirm_id'):
            return self.identity(stage, text)
        if stage in ('demo_service', 'demo_tx_amount', 'demo_tx_confirm'):
            return self.demo_balance_turn(stage, text)
        if stage.startswith('open_'):
            return self.open_demo_profile(stage, text)
        if stage == 'service':
            intent = intent_of(text)
            if not intent:
                s['unclear'] += 1
                if s['unclear'] >= 3:
                    self.run_tool(finish, 'human', 'unclear_intent')
                    return HUMAN
                return "I didn't catch the request. " + MENU
            s['intent_tag'] = intent
            row = self.run_tool(lookup_account, self.rows)
            if not row:
                return self.deliver()
            if intent == 'balance' and s.get('demo_balance_active'):
                return 'Your simulated balance is ' + str(s['demo_balance']) + ' rupees. No real funds are held here.'
            if intent in ('deposit', 'withdraw'):
                self.trace.append('check_status')
                if not check_status(s, row):
                    return self.deliver()
                s.update(intent_tag='demo_' + intent, demo_balance=Decimal(str(row.get('balance') or 0)), demo_balance_active=True, demo_tx_amount='', demo_return_stage='service', stage='demo_tx_amount')
                action = 'deposit' if intent == 'deposit' else 'withdraw'
                return 'This is a simulated ' + action + ' on the fictional account only. No real money moves. ' + current_prompt(s)
            if intent == 'balance':
                self.run_tool(quote_balance, self.rows)
                return self.deliver()
            if intent in ('limit', 'statement'):
                self.trace.append('check_status')
                if not check_status(s, row):
                    return self.deliver()
            s['stage'] = 'months' if intent == 'statement' else 'channel'
        elif stage == 'months':
            value = period_value(text)
            if value:
                s.update(period=value, stage='confirm_period')
        elif stage == 'confirm_period':
            if text in YES:
                s['stage'] = 'delivery'
            elif text in NO:
                s['stage'] = 'months'
        elif stage == 'delivery':
            medium = {'digital': 'digital', 'email': 'digital', 'printed': 'printed', 'print': 'printed', 'post': 'printed'}.get(text, '')
            if medium:
                self.run_tool(quote_statement, self.rows, s['period'], medium)
                return self.deliver()
        elif stage == 'channel':
            s.update(input_channel=text, stage='date')
        elif stage == 'date':
            day = parse_day(text)
            if day:
                s.update(transfer_date=day, stage='amount')
        elif stage == 'amount':
            value = text.replace('rupees', '').strip()
            if value in ('limit only', 'just the limit', 'read the limit'):
                value = ''
            if value and positive(value) is None:
                n = spoken_int(value)
                if n is None or n <= 0:
                    return ASK['amount']
                value = str(n)
            self.run_tool(check_limit, self.rows, value, s['input_channel'], s['transfer_date'])
            return self.deliver()
        return current_prompt(s)

    def identity(self, stage, text):
        s = self.s
        if stage == 'id':
            if is_account_opening_request(text):
                s.update(stage='open_name', intent_tag='demo_account_opening')
                return 'I can guide you through a simulated Harbour Trust account opening. Use fictional details only. Do not enter real Aadhaar, PAN, phone, or birth-date information. ' + current_prompt(s)
            if intent_of(text):
                s['intent_tag'] = intent_of(text)
            key = compact_digits(text).upper()
            if not re.fullmatch('HT\\d{4}', key):
                if not intent_of(text) and self.invalid_identity_entry():
                    return HUMAN
                return 'Please say H T followed by four digits.'
            s.update(candidate=key, stage='dob')
        elif stage == 'dob':
            day = parse_day(text)
            if day:
                next_stage = 'confirm_id' if s.get('retry_stage') == 'dob' and s.get('ending') else 'ending'
                s.update(dob=day, stage=next_stage, retry_stage='')
            elif self.invalid_identity_entry():
                return HUMAN
        elif stage == 'ending':
            tail = compact_digits(text)
            if re.fullmatch('\\d{4}', tail):
                s.update(ending=tail, stage='confirm_id', retry_stage='')
            elif self.invalid_identity_entry():
                return HUMAN
        elif text in NO:
            s.update(candidate='', ending='', dob='', retry_stage='', attempts=0, stage='id')
        elif text in YES:
            verification = self.run_tool(verify_caller, self.rows, s['candidate'], s['dob'], s['ending'])
            result = verification['result']
            if result == 'verified':
                s.update(candidate='', dob='')
                if s['intent_tag']:
                    return self.process(s['intent_tag'])
                return MENU
            if result == 'human':
                return HUMAN
            if result == 'technical':
                return human_message(s) + ' ' + HUMAN
            failed_fields = verification.get('failed_fields', [])
            retry = failed_fields[0] if failed_fields else 'id'
            s[retry] = ''
            s.update(stage=retry, retry_stage=retry)
            return "I couldn't verify those details. " + ASK[retry]
        return current_prompt(s)

    def open_demo_profile(self, stage, text):
        s = self.s
        if stage == 'open_name':
            if len(text) >= 2 and re.search('[^\\W\\d_]', text, re.UNICODE):
                s['stage'] = 'open_phone'
        elif stage == 'open_phone':
            if compact_digits(text) == '0000000000':
                s['stage'] = 'open_dob'
            else:
                return 'Use only the fictional sample number 0000000000. No phone number is retained. ' + current_prompt(s)
        elif stage == 'open_dob':
            if parse_day(text):
                s['stage'] = 'open_aadhaar'
            else:
                return 'Please give a fictional date, for example 1 January 1900. It is used only for this simulated check. ' + current_prompt(s)
        elif stage in ('open_aadhaar', 'open_pan'):
            if stage == 'open_pan' and text.upper() == DEMO_PAN:
                s['stage'] = 'open_confirm'
            elif clean(text).strip('.! ') in ('demo verified', 'verified', 'skip'):
                s['stage'] = 'open_pan' if stage == 'open_aadhaar' else 'open_confirm'
            else:
                if stage == 'open_aadhaar':
                    return 'For the simulation, say ‘demo verified’. Never share an Aadhaar number. ' + current_prompt(s)
                return 'Use only the sample token shown in the prompt or say ‘demo verified’. Never share a real PAN. ' + current_prompt(s)
        elif stage == 'open_confirm':
            if text in YES:
                s['stage'] = 'demo_service'
                s['demo_record_ready'] = True
                s['demo_balance_active'] = True
                return 'Your simulated profile is ready. A demo customer ID will be assigned now. No real bank account or KYC application has been created.'
            if text in NO:
                s.update(stage='id', intent_tag='', demo_record_ready=False)
                return 'No problem. The demo profile was cancelled. ' + WELCOME
        return current_prompt(s)

    def demo_balance_turn(self, stage, text):
        s = self.s
        if stage == 'demo_service':
            intent = intent_of(text)
            if intent == 'balance':
                return 'Your simulated demo balance is ' + str(s['demo_balance']) + ' rupees. No real funds are held here.'
            if intent in ('deposit', 'withdraw'):
                s.update(intent_tag='demo_' + intent, demo_tx_amount='', demo_return_stage='demo_service', stage='demo_tx_amount')
                action = 'deposit' if intent == 'deposit' else 'withdraw'
                return 'A simulated ' + action + ' only changes the balance in this browser session. No real money moves. ' + current_prompt(s)
            if re.search('\\b(?:finish|done|exit|stop)\\b', text):
                s['stage'] = 'closed'
                return 'Demo session ended. This was not a real bank account or transaction.'
            return 'You can check the demo balance, make a simulated deposit or withdrawal, or say finish.'
        if stage == 'demo_tx_amount':
            amount_text = text.lower().replace('rupees', '').replace('rupee', '').strip()
            amount = positive(amount_text)
            if amount is None:
                spoken = spoken_int(amount_text)
                amount = Decimal(spoken) if spoken is not None and spoken > 0 else None
            if amount is None or amount > Decimal('1000000'):
                return 'That amount is outside the demo range. Enter a positive amount. ' + current_prompt(s)
            s.update(demo_tx_amount=amount, stage='demo_tx_confirm')
            return 'I heard a simulated ' + s['intent_tag'].removeprefix('demo_') + ' of ' + str(amount) + ' rupees. ' + current_prompt(s)
        if stage == 'demo_tx_confirm':
            return_stage = s.get('demo_return_stage', 'demo_service')
            return_intent = 'demo_account_opening' if return_stage == 'demo_service' else ''
            if text in NO:
                s.update(demo_tx_amount='', intent_tag=return_intent, stage=return_stage)
                return 'Cancelled. Your demo balance is unchanged. ' + current_prompt(s)
            if text in YES:
                amount = Decimal(str(s['demo_tx_amount']))
                if s['intent_tag'] == 'demo_withdraw' and amount > Decimal(str(s['demo_balance'])):
                    s.update(demo_tx_amount='', intent_tag=return_intent, stage=return_stage)
                    return 'There are not enough simulated funds. Your demo balance is ' + str(s['demo_balance']) + ' rupees. ' + current_prompt(s)
                if s['intent_tag'] == 'demo_deposit':
                    s['demo_balance'] = Decimal(str(s['demo_balance'])) + amount
                    verb = 'deposit'
                else:
                    s['demo_balance'] = Decimal(str(s['demo_balance'])) - amount
                    verb = 'withdrawal'
                new_balance = s['demo_balance']
                s.update(demo_tx_amount='', intent_tag=return_intent, stage=return_stage)
                return 'Simulated ' + verb + ' recorded. Your demo balance is ' + str(new_balance) + ' rupees. No real money moved. ' + current_prompt(s)
        return current_prompt(s)

    def invalid_identity_entry(self):
        self.s['attempts'] += 1
        if self.s['attempts'] >= 3:
            self.run_tool(finish, 'human', 'verification')
            return True
        return False

    def deliver(self):
        s = self.s
        if s['handoff']:
            return (human_message(s) + ' ' + HUMAN).strip()
        q = s['quote']
        if not s['pending'] or not q:
            return current_prompt(s)
        if 'fee' in q and self.reserve and (not self.reserve(s['customer_id'], s['now_override'][:10])):
            self.run_tool(finish, 'human', 'already_sent')
            return human_message(s) + ' ' + HUMAN
        channel = s['pending']['channel']
        if 'balance' in q:
            answer = 'Your balance is ' + str(q['balance']) + ' rupees.'
        elif 'fee' in q:
            answer = 'Your statement has no fee.' if q['fee'] == 0 else 'Your statement fee is ' + str(q['fee']) + ' rupees.'
        else:
            answer = 'Your daily limit is ' + str(q['limit']) + ' rupees.'
        if channel.startswith('BankWire') and self.calendar:
            try:
                feed = self.calendar()
            except Exception:
                feed = {}
            advisory = uk_advisory(s['pending']['date'], feed)
            if advisory == "I couldn't check the UK clearing calendar.":
                self.run_tool(finish, 'human', 'calendar')
                return (human_message(s) + ' ' + HUMAN).strip()
            answer += ' ' + advisory
        self.run_tool(complete_handoff)
        return answer + ' ' + TERMS + ' Connecting you to ' + channel + '.'

DIRECTORY = [{'id': 'HT4102', 'dob': '1993-06-14', 'last4': '0042', 'customer_status': 'ACTIVE', 'account': 'A01', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 18420, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT8821', 'dob': '1986-01-27', 'last4': '9017', 'customer_status': 'ACTIVE', 'account': 'A02', 'plan': 'Premium', 'status': 'ACTIVE', 'balance': 94750, 'channel': 'BankWire', 'last_sent': ''}, {'id': 'HT1099', 'dob': '1998-08-09', 'last4': '3310', 'customer_status': 'BLOCKED', 'account': 'A03', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 6500, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT3340', 'dob': '1979-10-21', 'last4': '0088', 'customer_status': 'ACTIVE', 'account': 'A04', 'plan': 'Basic', 'status': 'FROZEN', 'balance': 8900, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT7712', 'dob': '1991-02-02', 'last4': '7721', 'customer_status': 'ACTIVE', 'account': 'A05', 'plan': 'Premium', 'status': 'DORMANT', 'balance': 60350, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT9999', 'dob': '2000-12-30', 'last4': '0403', 'customer_status': 'ACTIVE', 'account': 'A06', 'plan': 'Basic', 'status': None, 'balance': 5020, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT2219', 'dob': '1987-05-18', 'last4': '2135', 'customer_status': 'ACTIVE', 'account': 'A07', 'plan': 'Premium', 'status': 'ACTIVE', 'balance': 23000, 'channel': 'BankWire', 'last_sent': '2026-11-10'}, {'id': 'HT9011', 'dob': '1995-04-11', 'last4': '8493', 'customer_status': 'ACTIVE', 'account': None, 'plan': None, 'status': None, 'balance': None, 'channel': None, 'last_sent': None}, {'id': 'HT6543', 'dob': '2001-09-07', 'last4': '3000', 'customer_status': 'ACTIVE', 'account': 'A09', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 0, 'channel': 'Instant Pay', 'last_sent': '2026-11-09'}]

"""Appended to each standalone Studio tool by the builder. CES injects context."""
def _utterance(ctx):
    content = ctx.user_content
    values = []
    for part in getattr(content, "parts", []) or []:
        if getattr(part, "text", None):
            values.append(part.text)
        elif getattr(part, "blob", None):
            values.append(part.blob.transcript() or "")
    return " ".join(values)

def _session(ctx):
    state = fresh()
    for key in state:
        if key in ctx.state:
            state[key] = ctx.state[key]
    for key in ("transfer_date","input_channel"):
        state[key] = ctx.state.get(key,"")
    return state

def _advance(ctx, allowed):
    current = _session(ctx)
    invocation = str(ctx.invocation_id)
    cached = ctx.state.get("last_result",{})
    if cached and ctx.state.get("last_invocation") == invocation:
        return cached
    if current["stage"] not in allowed and not current["handoff"]:
        return {"stage":current["stage"],"wrong_tool":True}
    def calendar():
        return tools.uk_bank_holidays({})
    desk = Desk(DIRECTORY, state=current, calendar=calendar)
    reply = desk.turn(_utterance(ctx))
    if current.get("demo_record_ready"):
        from secrets import token_hex
        current.update(demo_customer_id="HTD-"+token_hex(6).upper(),demo_balance=0,
                       demo_balance_active=True,demo_record_ready=False)
        reply += " Demo customer ID: "+current["demo_customer_id"]+". This is simulated; no real bank account or KYC application was created."
    for k,v in current.items():
        ctx.state[k] = v
    result = {"say":reply,"stage":current["stage"],"verified":current["verified"],"handoff":current["handoff"]}
    ctx.state["last_result"] = result
    ctx.state["last_invocation"] = invocation
    return result

def verify_identity() -> dict:
    """Collect and confirm existing-caller details or advance the simulated account-opening flow. Never collect real government-ID numbers."""
    return _advance(context, ('id', 'dob', 'ending', 'confirm_id', 'open_name', 'open_phone', 'open_dob', 'open_aadhaar', 'open_pan', 'open_confirm'))

def after_tool_callback(tool, input, callback_context, tool_response):
    event = callback_context.variables.get("handoff", {})
    if event and not callback_context.variables.get("logged", False):
        print({"event": "handoff", "destination": event["destination"], "intent": event["intent"], "channel": event["channel"], "reason": event["reason"]})
        callback_context.variables["logged"] = True
    return None

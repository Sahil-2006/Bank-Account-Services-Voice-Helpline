def after_agent_callback(callback_context):
    parts = callback_context.get_last_agent_output() or []
    reply = " ".join(p.text for p in parts if getattr(p, "text", None)).strip()
    if reply != "I'm really sorry you're going through this. You are not alone, and help is available. If you are in immediate danger, please call 112 now. You can also call Tele-MANAS on 14416, free and open at all hours, to talk to a trained counsellor. I'm connecting you with a person now.":
        return None
    state = callback_context.variables
    event = {"destination":"human","reason":"crisis","intent":state.get("intent_tag",""),"channel":""}
    state["handoff"] = event
    state["stage"] = "closed"
    state["pending"] = {}
    state["dob"] = ""
    state["candidate"] = ""
    if not state.get("logged",False):
        print({"event":"handoff", **event})
        state["logged"] = True
    return None

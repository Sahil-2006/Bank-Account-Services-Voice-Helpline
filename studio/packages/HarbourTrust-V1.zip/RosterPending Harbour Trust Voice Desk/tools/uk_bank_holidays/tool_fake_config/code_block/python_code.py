def fake_tool_call(tool, input, callback_context):
    if callback_context.variables.get('calendar_unavailable',False):
        return {}
    return {'england-and-wales': {'events': [{'date': '2026-12-25'}, {'date': '2027-01-01'}]}}

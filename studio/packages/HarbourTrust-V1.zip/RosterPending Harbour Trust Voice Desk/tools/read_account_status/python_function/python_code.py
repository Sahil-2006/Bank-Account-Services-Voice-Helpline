"""Deterministic rules shared by the local desk and the Studio tool builder."""
import re
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_CEILING
NOW = '2026-11-10T09:00:00+05:30'
CRISIS = "I'm really sorry you're going through this. You are not alone, and help is available. If you are in immediate danger, please call 112 now. You can also call Tele-MANAS on 14416, free and open at all hours, to talk to a trained counsellor. I'm connecting you with a person now."
PRIVATE = 'Please keep card, Aadhaar and PIN numbers private. I only need the requested verification details.'
SAFE = 'I can only share verified account information from our tools. Would you like a person?'
TERMS = "Limits and fees follow the bank's terms."
HUMAN = "I'm connecting you with a person now."
TECH = "I couldn't retrieve the account information."
ADVICE = "I can't give financial advice. Would you like a person?"
OUTSIDE = 'I can help with bank account services. Would you like a person?'
DIGITS = 'zero one two three four five six seven eight nine'.split()
DIGIT_MAP = {**{word: str(i) for i, word in enumerate(DIGITS)}, 'oh': '0'}
NOW_DAY = NOW[:10]

def clean(text):
    return ' '.join(text.lower().replace('’', "'").strip().split())

def number_tokens(text):
    return re.sub('\\b(' + '|'.join(DIGIT_MAP) + ')\\b', lambda m: DIGIT_MAP[m.group()], clean(text))

def compact_digits(text):
    return re.sub('[\\s,.-]', '', number_tokens(text))

def classify(text):
    t = clean(text)
    if re.search("\\b(?:suicidal|suicide|kill myself|end my life|hurt myself|harm myself|take my own life|don't want to (?:live|be alive)|do not want to live|can't keep myself safe)\\b", t):
        return 'crisis'
    if re.fullmatch('(?:please\\s+)?(?:0|zero)[.!?]?', t) or re.search('\\b(?:agent|representative|someone|human|real person|a person)\\b', t):
        return 'human'
    numbers = number_tokens(t)
    if re.search('(?<!\\d)(?:\\d[\\s,-]*){12,}(?!\\d)', numbers) or (re.search('\\b(?:pin|card|aadhaar|aadhar)\\b', t) and re.search('\\d', numbers)):
        return 'private'
    if re.search('\\b(?:ignore|override|disregard)\\b.*\\b(?:instructions|rules|system)\\b|\\breveal (?:the |your )?system prompt\\b', t):
        return 'prompt'
    if re.search('\\bhow (?:can|do) i (?:hurt|harm|attack) (?:someone|a person|people)\\b', t):
        return 'harm'
    if re.search('\\b(?:invest|investment advice|buy stocks|sell shares|which stock|best mutual fund|should i borrow)\\b', t):
        return 'advice'
    if re.search('\\b(?:weather|recipe|pizza|football|flight|movie|train ticket)\\b', t):
        return 'outside'
    return ''

def intent_of(text):
    t = clean(text).strip('.!?')
    keypad = {'one': 'balance', '1': 'balance', 'two': 'statement', '2': 'statement', 'three': 'limit', '3': 'limit'}
    found = [i for i, pattern in (('balance', '\\bbalance\\b'), ('statement', '\\bstatements?\\b'), ('limit', '\\blimits?\\b')) if re.search(pattern, t)]
    return keypad.get(t, found[0] if len(found) == 1 else '')

def resolve_channel(name, transfer_date):
    try:
        day = date.fromisoformat(transfer_date)
    except (ValueError, TypeError):
        return ''
    cutover = date(2027, 1, 1)
    key = re.sub('[\\s-]+', '', clean(name))
    if key == 'instantpay':
        return 'Instant Pay'
    if key in ('bankwire', 'bankwireplus'):
        return 'BankWire Plus' if day >= cutover else 'BankWire'
    if key == 'passbookexpress' and day < cutover:
        return 'PassBook Express'
    return ''

def positive(value):
    try:
        n = Decimal(str(value).replace(',', '').strip())
        if n.is_finite() and n > 0:
            return n
    except (InvalidOperation, TypeError, ValueError):
        pass
    return None

def charge(months, delivery):
    n = positive(months)
    if n is None or delivery not in ('digital', 'printed'):
        return {'error': 'invalid'}
    if n > 36:
        return {'error': 'archive'}
    rounded = int(n.to_integral_value(rounding=ROUND_CEILING))
    fees = ((0, 100), (100, 250), (300, 500))
    tier = 0 if rounded <= 3 else 1 if rounded <= 12 else 2
    return {'months': rounded, 'fee': fees[tier][delivery == 'printed']}

def as_digits(value):
    return ' '.join((DIGITS[int(c)] for c in value if c.isdigit()))

def safe_output(text, allowed_money=()):
    if text == CRISIS:
        return text
    if re.search('(?:\\d[\\s,-]*){12,}', number_tokens(text)) or re.search('\\b(?:you should (?:buy|invest|sell)|i recommend investing)\\b', clean(text)):
        return SAFE
    amounts = re.findall('\\b([\\d,]+(?:\\.\\d+)?)\\s+rupees\\b', text.lower())
    if any((Decimal(v.replace(',', '')) not in allowed_money for v in amounts)):
        return SAFE
    return text

def uk_advisory(day, data):
    """The fictional BankWire UK clearing leg uses England and Wales only."""
    try:
        target = date.fromisoformat(day)
        events = data['england-and-wales']['events']
        listed = {date.fromisoformat(event['date']) for event in events}
        if target.year not in {d.year for d in listed}:
            raise ValueError('coverage')
        if target in listed or target.weekday() >= 5:
            return 'UK clearing may be delayed by a weekend or bank holiday.'
        return 'The UK calendar shows a weekday with no listed bank holiday.'
    except (KeyError, ValueError, TypeError):
        return "I couldn't check the UK clearing calendar."

"""Rules take a server-owned session and the fictional directory as inputs."""

def fresh():
    return dict(verified=False, customer_id='', account_type='', intent_tag='', channel='', attempts=0, unclear=0, now_override=NOW, handoff={}, pending={}, quote={}, stage='id', candidate='', ending='', dob='', period='', delivery='', offered=False)

def finish(s, destination, reason, channel=''):
    if not s['handoff']:
        s['handoff'] = {'destination': destination, 'reason': reason, 'intent': s['intent_tag'], 'channel': channel}
        s['stage'] = 'closed'
        s['pending'] = {}
        s['dob'] = ''
        s['candidate'] = ''
    return s['handoff']

def verify_caller(s, directory, customer_id, dob, last_four):
    if s['handoff']:
        return {'result': 'closed'}
    if s['verified']:
        return {'result': 'verified'}
    key = compact_digits(customer_id).upper()
    rows = [r for r in directory if r['id'] == key and r['dob'] == dob and (r['last4'] == compact_digits(last_four))]
    s['attempts'] += 1
    if len(rows) == 1 and rows[0]['customer_status'] == 'ACTIVE':
        s.update(verified=True, customer_id=key, ending=rows[0]['last4'], stage='service')
        return {'result': 'verified'}
    if len(rows) == 1 and rows[0]['customer_status'] == 'BLOCKED':
        finish(s, 'human', 'restricted')
        return {'result': 'human'}
    if s['attempts'] >= 3:
        finish(s, 'human', 'verification')
        return {'result': 'human'}
    return {'result': 'retry'}

def lookup_account(s, directory):
    if not s['verified'] or s['handoff']:
        return {}
    row = next((r for r in directory if r['id'] == s['customer_id']), None)
    if not row or not row['account']:
        finish(s, 'human', 'lookup')
        return {}
    s['account_type'] = row['plan'] or ''
    return row

def check_status(s, row):
    if not row:
        return False
    if s['intent_tag'] != 'statement' and row['status'] != 'ACTIVE':
        reason = 'status' if row['status'] in ('FROZEN', 'DORMANT') else 'unknown_status'
        finish(s, 'human', reason)
        return False
    return True

def quote_balance(s, rows):
    row = lookup_account(s, rows)
    if s['intent_tag'] != 'balance' or not check_status(s, row):
        return {}
    if row['balance'] is None:
        finish(s, 'human', 'lookup')
        return {}
    return prepare(s, row, {'balance': row['balance']}, row['channel'], s['now_override'][:10])

def quote_statement(s, rows, months, delivery, sent_today=False):
    row = lookup_account(s, rows)
    if not row or s['intent_tag'] != 'statement':
        return {}
    if sent_today or row['last_sent'] == s['now_override'][:10]:
        finish(s, 'human', 'already_sent')
        return {}
    q = charge(months, delivery)
    if q.get('error') == 'archive':
        finish(s, 'human', 'archive')
        return {}
    if 'error' in q:
        return q
    q['delivery'] = delivery
    return prepare(s, row, q, row['channel'], s['now_override'][:10])

def check_limit(s, rows, amount, channel, transfer_date):
    row = lookup_account(s, rows)
    if s['intent_tag'] != 'limit' or not check_status(s, row):
        return {}
    cap = {'Basic': 25000, 'Premium': 100000}.get(row['plan'])
    if cap is None:
        finish(s, 'human', 'unknown_plan')
        return {}
    if not resolve_channel(channel, transfer_date):
        finish(s, 'human', 'unsupported_channel')
        return {}
    if amount != '' and positive(amount) is None:
        return {'error': 'invalid'}
    if amount != '' and positive(amount) > cap:
        finish(s, 'human', 'above_limit')
        return {}
    return prepare(s, row, {'limit': cap}, channel, transfer_date)

def prepare(s, row, quote, channel, day):
    route = resolve_channel(channel or '', day)
    if not route:
        finish(s, 'human', 'unsupported_channel')
        return {}
    s.update(channel=route, quote=quote, pending={'channel': route, 'date': day})
    return quote

def complete_handoff(s):
    if s['verified'] and s['pending'] and s['quote'] and (not s['handoff']):
        return finish(s, 'channel', 'service_complete', s['pending']['channel'])
    return s['handoff']

def human_message(s):
    from_reason = {'lookup': TECH, 'unknown_status': TECH, 'unknown_plan': TECH, 'already_sent': 'A statement was already sent today.', 'archive': 'This period needs help from a colleague.', 'above_limit': 'That amount exceeds the daily limit.', 'unsupported_channel': 'That channel is unavailable for this transfer.', 'status': 'This account needs help from a colleague.'}
    return from_reason.get(s['handoff'].get('reason'), '')

"""Conversation controller. Only synthetic directory records reach this module."""
import re
from datetime import date, datetime
from decimal import Decimal
WELCOME = 'Welcome to Harbour Trust. What is your customer ID?'
MENU = 'Would you like your balance, a statement, or a transfer limit?'
ASK = {'id': 'What is your customer ID?', 'dob': 'What is your date of birth?', 'ending': 'What are the last four account digits?', 'service': MENU, 'months': 'How many months should the statement cover?', 'delivery': 'Would you like a digital or printed copy?', 'amount': 'What transfer amount should I check, or should I just read the limit?', 'channel': 'Which transfer channel will you use?', 'date': 'On what date will you make the transfer?'}
YES = {'yes', 'yeah', 'correct', "that's right", 'right', 'yes please', 'that is correct'}
NO = {'no', 'incorrect', 'wrong', 'no thanks', 'no thank you'}

def parse_day(text):
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d %B %Y', '%B %d %Y', '%d %b %Y'):
        try:
            return datetime.strptime(text.replace(',', '').strip(), fmt).date().isoformat()
        except ValueError:
            pass
    return ''

def period_value(text):
    t = clean(text).replace(' and a half', '.5')
    for w, n in {'twelve': '12', 'thirty six': '36', 'three': '3', 'six': '6', 'one': '1'}.items():
        t = re.sub('\\b' + w + '\\b', n, t)
    m = re.fullmatch('([+-]?\\d+(?:\\.\\d+)?)\\s*(?:months?)?[.!]?', t.replace(' .', '.'))
    return m.group(1) if m and positive(m.group(1)) else ''

def current_prompt(s):
    if s['stage'] == 'confirm_id':
        return 'I heard H T ' + as_digits(s['candidate'][2:]) + ', ending ' + as_digits(s['ending']) + '. Is that right?'
    if s['stage'] == 'confirm_period':
        return 'You asked for ' + s['period'] + ' months. Is that right?'
    return ASK.get(s['stage'], MENU)

class Desk:

    def __init__(self, directory, state=None, calendar=None, reserve=None, callback=None):
        self.rows = directory
        self.s = state if state is not None else fresh()
        self.calendar = calendar
        self.reserve = reserve
        self.callback = callback
        self.trace = []

    def run_tool(self, func, *args):
        self.trace.append(func.__name__)
        return func(self.s, *args)

    def turn(self, raw):
        s = self.s
        if s['handoff']:
            return 'This call has ended.'
        text = clean(raw).strip('!?')
        kind = classify(text)
        if kind in ('crisis', 'human'):
            if not s['intent_tag']:
                s['intent_tag'] = intent_of(text)
            self.run_tool(finish, 'human', kind)
            reply = CRISIS if kind == 'crisis' else HUMAN
        elif kind == 'private':
            reply = PRIVATE
        elif kind in ('prompt', 'harm'):
            reply = SAFE
            s['offered'] = True
        elif kind in ('advice', 'outside'):
            s['offered'] = True
            reply = ADVICE if kind == 'advice' else OUTSIDE
        elif s['offered'] and text in YES:
            self.run_tool(finish, 'human', 'accepted_offer')
            reply = HUMAN
        elif not text:
            reply = 'Take your time. ' + current_prompt(s)
        elif re.search('\\b(?:what can you do|what services|what do you do)\\b', text):
            reply = 'I can check a balance, arrange a statement, or look up a transfer limit. ' + current_prompt(s)
        else:
            if s['offered'] and text in NO:
                reply = current_prompt(s)
            else:
                reply = self.process(text)
            s['offered'] = False
        if s['handoff'] and self.callback:
            self.callback(dict(s['handoff']))
        allowed = [Decimal(str(v)) for k, v in s['quote'].items() if k in ('balance', 'fee', 'limit')]
        return safe_output(reply, allowed)

    def process(self, text):
        s = self.s
        stage = s['stage']
        if stage in ('id', 'dob', 'ending', 'confirm_id'):
            return self.identity(stage, text)
        if stage == 'service':
            intent = intent_of(text)
            if not intent:
                s['unclear'] += 1
                if s['unclear'] >= 3:
                    self.run_tool(finish, 'human', 'unclear_intent')
                    return HUMAN
                return "I didn't catch the request. " + MENU
            s['intent_tag'] = intent
            row = self.run_tool(lookup_account, self.rows)
            if not row:
                return self.deliver()
            if intent == 'balance':
                self.run_tool(quote_balance, self.rows)
                return self.deliver()
            if intent == 'limit':
                self.trace.append('check_status')
                if not check_status(s, row):
                    return self.deliver()
            s['stage'] = 'months' if intent == 'statement' else 'channel'
        elif stage == 'months':
            value = period_value(text)
            if value:
                s.update(period=value, stage='confirm_period')
        elif stage == 'confirm_period':
            if text in YES:
                s['stage'] = 'delivery'
            elif text in NO:
                s['stage'] = 'months'
        elif stage == 'delivery':
            medium = {'digital': 'digital', 'email': 'digital', 'printed': 'printed', 'print': 'printed', 'post': 'printed'}.get(text, '')
            if medium:
                self.run_tool(quote_statement, self.rows, s['period'], medium)
                return self.deliver()
        elif stage == 'channel':
            s.update(input_channel=text, stage='date')
        elif stage == 'date':
            day = parse_day(text)
            if day:
                s.update(transfer_date=day, stage='amount')
        elif stage == 'amount':
            value = text.replace('rupees', '').strip()
            if value in ('limit only', 'just the limit', 'read the limit'):
                value = ''
            if value and positive(value) is None:
                return ASK['amount']
            self.run_tool(check_limit, self.rows, value, s['input_channel'], s['transfer_date'])
            return self.deliver()
        return current_prompt(s)

    def identity(self, stage, text):
        s = self.s
        if stage == 'id':
            if intent_of(text):
                s['intent_tag'] = intent_of(text)
            key = compact_digits(text).upper()
            if not re.fullmatch('HT\\d{4}', key):
                return 'Please say H T followed by four digits.'
            s.update(candidate=key, stage='dob')
        elif stage == 'dob':
            day = parse_day(text)
            if day:
                s.update(dob=day, stage='ending')
        elif stage == 'ending':
            tail = compact_digits(text)
            if re.fullmatch('\\d{4}', tail):
                s.update(ending=tail, stage='confirm_id')
        elif text in NO:
            s.update(candidate='', ending='', dob='', stage='id')
        elif text in YES:
            result = self.run_tool(verify_caller, self.rows, s['candidate'], s['dob'], s['ending'])['result']
            s.update(candidate='', dob='')
            if result == 'verified':
                if s['intent_tag']:
                    return self.process(s['intent_tag'])
                return MENU
            if result == 'human':
                return HUMAN
            s.update(stage='id', ending='')
            return "I couldn't verify those details. " + ASK['id']
        return current_prompt(s)

    def deliver(self):
        s = self.s
        if s['handoff']:
            return (human_message(s) + ' ' + HUMAN).strip()
        q = s['quote']
        if not s['pending'] or not q:
            return current_prompt(s)
        if 'fee' in q and self.reserve and (not self.reserve(s['customer_id'], s['now_override'][:10])):
            self.run_tool(finish, 'human', 'already_sent')
            return human_message(s) + ' ' + HUMAN
        channel = s['pending']['channel']
        if 'balance' in q:
            answer = 'Your balance is ' + str(q['balance']) + ' rupees.'
        elif 'fee' in q:
            answer = 'Your statement has no fee.' if q['fee'] == 0 else 'Your statement fee is ' + str(q['fee']) + ' rupees.'
        else:
            answer = 'Your daily limit is ' + str(q['limit']) + ' rupees.'
        if channel.startswith('BankWire') and self.calendar:
            try:
                feed = self.calendar()
            except Exception:
                feed = {}
            answer += ' ' + uk_advisory(s['pending']['date'], feed)
        self.run_tool(complete_handoff)
        return answer + ' ' + TERMS + ' Connecting you to ' + channel + '.'

DIRECTORY = [{'id': 'HT4102', 'dob': '1993-06-14', 'last4': '0042', 'customer_status': 'ACTIVE', 'account': 'A01', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 18420, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT5103', 'dob': '1986-01-27', 'last4': '9017', 'customer_status': 'ACTIVE', 'account': 'A02', 'plan': 'Premium', 'status': 'ACTIVE', 'balance': 94750, 'channel': 'BankWire', 'last_sent': ''}, {'id': 'HT6314', 'dob': '1998-08-09', 'last4': '3310', 'customer_status': 'BLOCKED', 'account': 'A03', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 6500, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT7405', 'dob': '1979-10-21', 'last4': '0088', 'customer_status': 'ACTIVE', 'account': 'A04', 'plan': 'Basic', 'status': 'FROZEN', 'balance': 8900, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT8506', 'dob': '1991-02-02', 'last4': '7721', 'customer_status': 'ACTIVE', 'account': 'A05', 'plan': 'Premium', 'status': 'DORMANT', 'balance': 60350, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT9607', 'dob': '2000-12-30', 'last4': '0403', 'customer_status': 'ACTIVE', 'account': 'A06', 'plan': 'Basic', 'status': None, 'balance': 5020, 'channel': 'Instant Pay', 'last_sent': ''}, {'id': 'HT1708', 'dob': '1987-05-18', 'last4': '2135', 'customer_status': 'ACTIVE', 'account': 'A07', 'plan': 'Premium', 'status': 'ACTIVE', 'balance': 23000, 'channel': 'BankWire', 'last_sent': '2026-11-10'}, {'id': 'HT2809', 'dob': '1995-04-11', 'last4': '8493', 'customer_status': 'ACTIVE', 'account': None, 'plan': None, 'status': None, 'balance': None, 'channel': None, 'last_sent': None}, {'id': 'HT3901', 'dob': '2001-09-07', 'last4': '3000', 'customer_status': 'ACTIVE', 'account': 'A09', 'plan': 'Basic', 'status': 'ACTIVE', 'balance': 0, 'channel': 'Instant Pay', 'last_sent': '2026-11-09'}]

"""Appended to each standalone Studio tool by the builder. CES injects context."""
def _utterance(ctx):
    content = ctx.user_content
    values = []
    for part in getattr(content, "parts", []) or []:
        if getattr(part, "text", None):
            values.append(part.text)
        elif getattr(part, "blob", None):
            values.append(part.blob.transcript() or "")
    return " ".join(values)

def _session(ctx):
    state = fresh()
    for key in state:
        if key in ctx.state:
            state[key] = ctx.state[key]
    for key in ("transfer_date","input_channel"):
        state[key] = ctx.state.get(key,"")
    return state

def _advance(ctx, allowed):
    current = _session(ctx)
    invocation = str(ctx.invocation_id)
    cached = ctx.state.get("last_result",{})
    if cached and ctx.state.get("last_invocation") == invocation:
        return cached
    if current["stage"] not in allowed and not current["handoff"]:
        return {"stage":current["stage"],"wrong_tool":True}
    def calendar():
        return tools.uk_bank_holidays({})
    desk = Desk(DIRECTORY, state=current, calendar=calendar)
    reply = desk.turn(_utterance(ctx))
    for k,v in current.items():
        ctx.state[k] = v
    result = {"say":reply,"stage":current["stage"],"verified":current["verified"],"handoff":current["handoff"]}
    ctx.state["last_result"] = result
    ctx.state["last_invocation"] = invocation
    return result

def read_account_status() -> dict:
    """Read verified status for balance and limit requests. Statements skip this check."""
    s = _session(context)
    row = lookup_account(s, DIRECTORY)
    return {"status": (row.get("status") or "UNKNOWN") if row and s["intent_tag"] in ("balance","limit") else "UNAVAILABLE"}
